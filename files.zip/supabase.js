import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    'Supabase-Umgebungsvariablen fehlen. Bitte .env aus .env.example anlegen.'
  )
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// ---- Auth Helpers -------------------------------------------------

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  })
  if (error) throw error
  return data
}

export async function signUp(email, password) {
  const { data, error } = await supabase.auth.signUp({ email, password })
  if (error) throw error
  return data
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

// ---- Customers ------------------------------------------------------

export async function getCustomers() {
  const { data, error } = await supabase
    .from('customers')
    .select('*, projects(id)')
    .order('name', { ascending: true })
  if (error) throw error
  return data
}

export async function getCustomer(id) {
  const { data, error } = await supabase
    .from('customers')
    .select('*, projects(*, invoices(id, total))')
    .eq('id', id)
    .single()
  if (error) throw error
  return data
}

export async function createCustomer(customer) {
  const { data, error } = await supabase
    .from('customers')
    .insert(customer)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function updateCustomer(id, updates) {
  const { data, error } = await supabase
    .from('customers')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function deleteCustomer(id) {
  const { error } = await supabase.from('customers').delete().eq('id', id)
  if (error) throw error
}

// ---- Projects -------------------------------------------------------

export async function getProjects() {
  const { data, error } = await supabase
    .from('projects')
    .select('*, customers(id, name, address)')
    .order('created_at', { ascending: false })
  if (error) throw error
  return data
}

export async function getProject(id) {
  const { data, error } = await supabase
    .from('projects')
    .select('*, customers(id, name, address), invoices(*)')
    .eq('id', id)
    .single()
  if (error) throw error
  return data
}

export async function createProject(project) {
  const { data, error } = await supabase
    .from('projects')
    .insert(project)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function updateProject(id, updates) {
  const { data, error } = await supabase
    .from('projects')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function deleteProject(id) {
  const { error } = await supabase.from('projects').delete().eq('id', id)
  if (error) throw error
}

// ---- Invoices / Angebote --------------------------------------------

export async function getInvoices() {
  const { data, error } = await supabase
    .from('invoices')
    .select('*, projects(id, name, customers(name))')
    .order('date', { ascending: false })
  if (error) throw error
  return data
}

export async function getInvoice(id) {
  const { data, error } = await supabase
    .from('invoices')
    .select('*, invoice_items(*), projects(id, name, customers(*))')
    .eq('id', id)
    .single()
  if (error) throw error
  return data
}

export async function createInvoice(invoice) {
  const { data, error } = await supabase
    .from('invoices')
    .insert(invoice)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function updateInvoice(id, updates) {
  const { data, error } = await supabase
    .from('invoices')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function deleteInvoice(id) {
  const { error } = await supabase.from('invoices').delete().eq('id', id)
  if (error) throw error
}

// ---- Invoice Items ----------------------------------------------------

export async function replaceInvoiceItems(invoiceId, items) {
  // Einfachster Ansatz: alte Positionen löschen, neue einfügen
  const { error: delError } = await supabase
    .from('invoice_items')
    .delete()
    .eq('invoice_id', invoiceId)
  if (delError) throw delError

  if (items.length === 0) return []

  const { data, error } = await supabase
    .from('invoice_items')
    .insert(items.map((item) => ({ ...item, invoice_id: invoiceId })))
    .select()
  if (error) throw error
  return data
}
