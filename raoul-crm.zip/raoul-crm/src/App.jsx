import { useEffect, useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { supabase } from './lib/supabase.js'

import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Customers from './pages/Customers.jsx'
import CustomerDetail from './pages/CustomerDetail.jsx'
import Projects from './pages/Projects.jsx'
import ProjectDetail from './pages/ProjectDetail.jsx'
import Offers from './pages/Offers.jsx'
import OfferCreate from './pages/OfferCreate.jsx'

export default function App() {
  const [session, setSession] = useState(undefined) // undefined = wird geladen

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session))

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession)
    })

    return () => listener.subscription.unsubscribe()
  }, [])

  // Noch am Prüfen, ob eine Session existiert
  if (session === undefined) {
    return (
      <div className="min-h-screen flex items-center justify-center text-slate-400 text-sm">
        Wird geladen …
      </div>
    )
  }

  const user = session?.user ?? null

  return (
    <Routes>
      <Route
        path="/login"
        element={user ? <Navigate to="/" replace /> : <Login />}
      />

      <Route
        path="/"
        element={user ? <Dashboard user={user} /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/kunden"
        element={user ? <Customers user={user} /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/kunden/:id"
        element={user ? <CustomerDetail user={user} /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/projekte"
        element={user ? <Projects user={user} /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/projekte/:id"
        element={user ? <ProjectDetail user={user} /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/angebote"
        element={user ? <Offers user={user} /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/angebote/neu/:projectId"
        element={user ? <OfferCreate user={user} /> : <Navigate to="/login" replace />}
      />
      <Route
        path="/angebote/:id"
        element={user ? <OfferCreate user={user} /> : <Navigate to="/login" replace />}
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
