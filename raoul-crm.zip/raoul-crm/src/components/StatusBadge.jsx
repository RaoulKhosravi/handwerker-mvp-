const STYLES = {
  'In Arbeit': 'bg-blue-50 text-blue-600 border-blue-200',
  Offen: 'bg-amber-50 text-amber-600 border-amber-200',
  Fertig: 'bg-green-50 text-green-600 border-green-200'
}

export default function StatusBadge({ status }) {
  const style = STYLES[status] || 'bg-slate-50 text-slate-600 border-slate-200'
  return (
    <span
      className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded border ${style}`}
    >
      {status}
    </span>
  )
}
