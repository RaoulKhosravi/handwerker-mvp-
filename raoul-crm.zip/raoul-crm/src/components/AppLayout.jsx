import Sidebar from './Sidebar.jsx'

export default function AppLayout({ user, title, children }) {
  return (
    <div className="flex min-h-screen bg-surface">
      <Sidebar user={user} />
      <main className="flex-1 min-w-0">
        <div className="h-16 border-b border-slate-200 bg-white flex items-center px-8">
          <h1 className="text-sm font-semibold text-slate-700">{title}</h1>
        </div>
        <div className="p-8">{children}</div>
      </main>
    </div>
  )
}
