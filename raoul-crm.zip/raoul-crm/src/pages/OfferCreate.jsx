import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import AppLayout from '../components/AppLayout.jsx'
import {
  getProject,
  getInvoice,
  createInvoice,
  updateInvoice,
  replaceInvoiceItems
} from '../lib/supabase.js'

const MWST_RATE = 0.19

export default function OfferCreate({ user }) {
  const { id, projectId } = useParams()
  const navigate = useNavigate()
  const isEdit = Boolean(id)

  const [project, setProject] = useState(null)
  const [invoiceId, setInvoiceId] = useState(id || null)
  const [title, setTitle] = useState('')
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [validUntil, setValidUntil] = useState('')
  const [customerName, setCustomerName] = useState('')
  const [paymentTerms, setPaymentTerms] = useState('14 Tage netto')
  const [remarks, setRemarks] = useState('Angebot gültig für 30 Tage. Preise inkl. Anfahrt und Entsorgung.')
  const [items, setItems] = useState([{ description: '', quantity: 1, price: 0 }])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [generatingPdf, setGeneratingPdf] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    async function load() {
      try {
        if (isEdit) {
          const inv = await getInvoice(id)
          setProject(inv.projects)
          setInvoiceId(inv.id)
          setTitle(inv.title)
          setDate(inv.date)
          setCustomerName(inv.projects?.customers?.name || '')
          setItems(
            inv.invoice_items?.length
              ? inv.invoice_items.map((it) => ({
                  description: it.description,
                  quantity: it.quantity,
                  price: it.price
                }))
              : [{ description: '', quantity: 1, price: 0 }]
          )
        } else {
          const p = await getProject(projectId)
          setProject(p)
          setCustomerName(p.customers?.name || '')
          setTitle(`Angebot – ${p.name}`)
        }
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [id, projectId, isEdit])

  const netTotal = items.reduce(
    (sum, it) => sum + Number(it.quantity || 0) * Number(it.price || 0),
    0
  )
  const vat = netTotal * MWST_RATE
  const grandTotal = netTotal + vat

  function updateItem(index, field, value) {
    setItems(items.map((it, i) => (i === index ? { ...it, [field]: value } : it)))
  }

  function addItem() {
    setItems([...items, { description: '', quantity: 1, price: 0 }])
  }

  function removeItem(index) {
    setItems(items.filter((_, i) => i !== index))
  }

  async function handleSave() {
    setSaving(true)
    setError('')
    try {
      let currentInvoiceId = invoiceId
      const payload = { title, date, total: grandTotal }

      if (isEdit) {
        await updateInvoice(invoiceId, payload)
      } else {
        const created = await createInvoice({ ...payload, project_id: projectId })
        currentInvoiceId = created.id
        setInvoiceId(created.id)
      }

      await replaceInvoiceItems(currentInvoiceId, items.filter((it) => it.description))
      return currentInvoiceId
    } catch (err) {
      setError(err.message)
      throw err
    } finally {
      setSaving(false)
    }
  }

  async function handleGeneratePdf() {
    setGeneratingPdf(true)
    setError('')
    try {
      const savedId = await handleSave()
      const res = await fetch('/api/pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          date,
          validUntil,
          customerName,
          paymentTerms,
          remarks,
          items,
          netTotal,
          vat,
          grandTotal
        })
      })
      if (!res.ok) throw new Error('PDF konnte nicht erstellt werden')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${title || 'Angebot'}.pdf`
      a.click()
      URL.revokeObjectURL(url)
      if (!isEdit && savedId) navigate(`/angebote/${savedId}`)
    } catch (err) {
      setError(err.message)
    } finally {
      setGeneratingPdf(false)
    }
  }

  if (loading) {
    return (
      <AppLayout user={user} title="Angebot erstellen">
        <p className="text-sm text-slate-400">Wird geladen …</p>
      </AppLayout>
    )
  }

  return (
    <AppLayout user={user} title="Angebot erstellen">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Angebot erstellen</h2>
          <p className="text-sm text-slate-500">
            {customerName} · {project?.name}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 text-sm rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-60"
          >
            💾 {saving ? 'Speichert …' : 'Speichern'}
          </button>
          <button
            onClick={handleGeneratePdf}
            disabled={generatingPdf}
            className="flex items-center gap-2 px-4 py-2 text-sm rounded-lg bg-accent text-white font-medium hover:bg-accent-dark disabled:opacity-60"
          >
            ↓ {generatingPdf ? 'Erstellt PDF …' : 'PDF generieren'}
          </button>
        </div>
      </div>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="font-semibold text-slate-700 mb-4">Angebotsdetails</h3>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <Field label="Titel" value={title} onChange={setTitle} />
              <Field label="Datum" type="date" value={date} onChange={setDate} />
              <Field label="Gültig bis" type="date" value={validUntil} onChange={setValidUntil} />
              <Field label="Kunde" value={customerName} onChange={setCustomerName} />
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-700">Positionen</h3>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-slate-400 uppercase text-left">
                  <th className="py-2 font-medium">Beschreibung</th>
                  <th className="py-2 font-medium w-20">Menge</th>
                  <th className="py-2 font-medium w-28">Einzelpreis</th>
                  <th className="py-2 font-medium w-28 text-right">Gesamt</th>
                  <th className="w-8" />
                </tr>
              </thead>
              <tbody>
                {items.map((it, i) => (
                  <tr key={i} className="border-t border-slate-100">
                    <td className="py-2 pr-2">
                      <input
                        value={it.description}
                        onChange={(e) => updateItem(i, 'description', e.target.value)}
                        className="w-full rounded border border-slate-200 px-2 py-1 text-sm"
                      />
                    </td>
                    <td className="py-2 pr-2">
                      <input
                        type="number"
                        value={it.quantity}
                        onChange={(e) => updateItem(i, 'quantity', e.target.value)}
                        className="w-full rounded border border-slate-200 px-2 py-1 text-sm"
                      />
                    </td>
                    <td className="py-2 pr-2">
                      <input
                        type="number"
                        step="0.01"
                        value={it.price}
                        onChange={(e) => updateItem(i, 'price', e.target.value)}
                        className="w-full rounded border border-slate-200 px-2 py-1 text-sm"
                      />
                    </td>
                    <td className="py-2 text-right text-slate-700">
                      {(Number(it.quantity || 0) * Number(it.price || 0)).toLocaleString('de-DE', {
                        minimumFractionDigits: 2
                      })}{' '}
                      €
                    </td>
                    <td className="py-2 text-right">
                      <button
                        onClick={() => removeItem(i)}
                        className="text-slate-400 hover:text-red-500"
                      >
                        🗑
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button
              onClick={addItem}
              className="text-accent text-sm font-medium hover:underline mt-3"
            >
              + Position hinzufügen
            </button>
          </div>
        </div>

        <div className="col-span-1 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5 text-sm">
            <h3 className="font-semibold text-slate-700 mb-3">Zusammenfassung</h3>
            <SummaryRow label="Nettobetrag" value={netTotal} />
            <SummaryRow label="MwSt. (19 %)" value={vat} />
            <div className="border-t border-slate-100 mt-2 pt-2 flex justify-between font-bold text-slate-800">
              <span>Gesamtbetrag</span>
              <span>{grandTotal.toLocaleString('de-DE', { minimumFractionDigits: 2 })} €</span>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 text-sm">
            <h3 className="font-semibold text-slate-700 mb-3">Zahlungsbedingungen</h3>
            <label className="block text-xs text-slate-400 mb-1">Zahlungsziel</label>
            <select
              value={paymentTerms}
              onChange={(e) => setPaymentTerms(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm mb-4"
            >
              <option>Sofort fällig</option>
              <option>7 Tage netto</option>
              <option>14 Tage netto</option>
              <option>30 Tage netto</option>
            </select>
            <label className="block text-xs text-slate-400 mb-1">Anmerkungen</label>
            <textarea
              rows={4}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
            />
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-700">
            Nach dem Speichern kann das Angebot als PDF heruntergeladen und per E-Mail versendet
            werden.
          </div>
        </div>
      </div>
    </AppLayout>
  )
}

function Field({ label, value, onChange, type = 'text' }) {
  return (
    <div>
      <label className="block text-xs text-slate-400 mb-1">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
      />
    </div>
  )
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex justify-between py-1">
      <span className="text-slate-500">{label}</span>
      <span className="text-slate-800">
        {value.toLocaleString('de-DE', { minimumFractionDigits: 2 })} €
      </span>
    </div>
  )
}
