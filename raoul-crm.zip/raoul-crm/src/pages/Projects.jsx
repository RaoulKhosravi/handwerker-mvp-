import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import AppLayout from '../components/AppLayout.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import { getProjects } from '../lib/supabase.js'

export default function Projects({ user }) {
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filter, setFilter] = useState('Alle')

  useEffect(() => {
    getProjects()
      .then(setProjects)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [])

  const filtered =
    filter === 'Alle' ? projects : projects.filter((p) => p.status === filter)

  return (
    <AppLayout user={user} title="Projekte">
      <div className="flex items-center justify-between mb-1">
        <h2 className="text-2xl font-bold text-slate-800">Projekte</h2>
      </div>
      <p className="text-sm text-slate-500 mb-6">{projects.length} Projekte insgesamt</p>

      <div className="flex gap-2 mb-4">
        {['Alle', 'Offen', 'In Arbeit', 'Fertig'].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`text-sm px-3 py-1.5 rounded-lg border ${
              filter === s
                ? 'bg-sidebar text-white border-sidebar'
                : 'border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {loading ? (
          <p className="px-6 py-6 text-sm text-slate-400">Wird geladen …</p>
        ) : filtered.length === 0 ? (
          <p className="px-6 py-6 text-sm text-slate-400">Keine Projekte gefunden.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-slate-400 uppercase text-left bg-slate-50">
                <th className="px-6 py-3 font-medium">Projekt</th>
                <th className="px-6 py-3 font-medium">Kunde</th>
                <th className="px-6 py-3 font-medium">Status</th>
                <th className="px-6 py-3 font-medium">Datum</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-6 py-3">
                    <Link to={`/projekte/${p.id}`} className="text-slate-700 font-medium hover:text-accent">
                      {p.name}
                    </Link>
                  </td>
                  <td className="px-6 py-3 text-accent">{p.customers?.name}</td>
                  <td className="px-6 py-3">
                    <StatusBadge status={p.status} />
                  </td>
                  <td className="px-6 py-3 text-slate-500">
                    {new Date(p.created_at).toLocaleDateString('de-DE')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </AppLayout>
  )
}
