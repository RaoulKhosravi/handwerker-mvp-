import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import AppLayout from '../components/AppLayout.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import { getCustomers, getProjects, getInvoices } from '../lib/supabase.js'

export default function Dashboard({ user }) {
  const [stats, setStats] = useState({ customers: 0, projects: 0, offers: 0 })
  const [recentProjects, setRecentProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    async function load() {
      try {
        const [customers, projects, invoices] = await Promise.all([
          getCustomers(),
          getProjects(),
          getInvoices()
        ])
        setStats({
          customers: customers.length,
          projects: projects.length,
          offers: invoices.length
        })
        setRecentProjects(projects.slice(0, 6))
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const today = new Date().toLocaleDateString('de-DE', {
    weekday: 'long',
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  })

  const firstName = (user?.user_metadata?.name || user?.email || 'Raoul').split(' ')[0].split('@')[0]

  return (
    <AppLayout user={user} title="Dashboard">
      <h2 className="text-2xl font-bold text-slate-800">Willkommen zurück, {firstName}</h2>
      <p className="text-sm text-slate-500 mb-6">{today} — Hier ist deine Übersicht</p>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <div className="grid grid-cols-3 gap-4 mb-8">
        <StatCard label="Kunden" value={stats.customers} to="/kunden" />
        <StatCard label="Projekte" value={stats.projects} to="/projekte" />
        <StatCard label="Angebote" value={stats.offers} to="/angebote" />
      </div>

      <div className="bg-white rounded-xl border border-slate-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-700">Aktuelle Projekte</h3>
          <Link to="/projekte" className="text-sm text-accent font-medium hover:underline">
            Alle anzeigen ›
          </Link>
        </div>

        {loading ? (
          <p className="px-6 py-6 text-sm text-slate-400">Wird geladen …</p>
        ) : recentProjects.length === 0 ? (
          <p className="px-6 py-6 text-sm text-slate-400">Noch keine Projekte angelegt.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-slate-400 uppercase text-left">
                <th className="px-6 py-2 font-medium">Projekt</th>
                <th className="px-6 py-2 font-medium">Kunde</th>
                <th className="px-6 py-2 font-medium">Status</th>
                <th className="px-6 py-2 font-medium">Datum</th>
              </tr>
            </thead>
            <tbody>
              {recentProjects.map((p) => (
                <tr key={p.id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-6 py-3">
                    <Link to={`/projekte/${p.id}`} className="text-slate-700 font-medium hover:text-accent">
                      {p.name}
                    </Link>
                  </td>
                  <td className="px-6 py-3 text-accent">{p.customers?.name}</td>
                  <td className="px-6 py-3">
                    <StatusBadge status={p.status} />
                  </td>
                  <td className="px-6 py-3 text-slate-500">
                    {new Date(p.created_at).toLocaleDateString('de-DE')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </AppLayout>
  )
}

function StatCard({ label, value, to }) {
  return (
    <Link
      to={to}
      className="bg-white rounded-xl border border-slate-200 px-5 py-4 hover:border-accent/40 transition"
    >
      <div className="text-xs font-medium text-slate-400 uppercase mb-2">{label}</div>
      <div className="text-3xl font-bold text-slate-800">{value}</div>
    </Link>
  )
}
