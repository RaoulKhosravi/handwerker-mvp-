import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import AppLayout from '../components/AppLayout.jsx'
import { getProject, updateProject, supabase } from '../lib/supabase.js'

export default function ProjectDetail({ user }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const [project, setProject] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const [photos, setPhotos] = useState([])
  const [uploading, setUploading] = useState(false)

  async function load() {
    setLoading(true)
    try {
      const data = await getProject(id)
      setProject({ ...data, materials: data.materials || [] })
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    loadPhotos()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  async function loadPhotos() {
    const { data, error: listError } = await supabase.storage
      .from('project-photos')
      .list(id, { limit: 20 })
    if (!listError && data) {
      const urls = data.map(
        (file) =>
          supabase.storage.from('project-photos').getPublicUrl(`${id}/${file.name}`).data
            .publicUrl
      )
      setPhotos(urls)
    }
  }

  async function handleUpload(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try {
      const path = `${id}/${Date.now()}-${file.name}`
      const { error: uploadError } = await supabase.storage
        .from('project-photos')
        .upload(path, file)
      if (uploadError) throw uploadError
      await loadPhotos()
    } catch (err) {
      setError(err.message)
    } finally {
      setUploading(false)
    }
  }

  async function handleSave(updates) {
    setSaving(true)
    try {
      const updated = await updateProject(id, updates)
      setProject((prev) => ({ ...prev, ...updated }))
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  function addMaterial() {
    const materials = [...project.materials, { name: '', quantity: '', price: 0 }]
    setProject({ ...project, materials })
  }

  function updateMaterial(index, field, value) {
    const materials = project.materials.map((m, i) =>
      i === index ? { ...m, [field]: value } : m
    )
    setProject({ ...project, materials })
  }

  function removeMaterial(index) {
    const materials = project.materials.filter((_, i) => i !== index)
    setProject({ ...project, materials })
    handleSave({ materials })
  }

  if (loading) {
    return (
      <AppLayout user={user} title="Projektseite">
        <p className="text-sm text-slate-400">Wird geladen …</p>
      </AppLayout>
    )
  }

  if (error && !project) {
    return (
      <AppLayout user={user} title="Projektseite">
        <p className="text-sm text-red-600">{error}</p>
      </AppLayout>
    )
  }

  return (
    <AppLayout user={user} title="Projektseite">
      <button
        onClick={() => navigate(-1)}
        className="text-slate-400 hover:text-slate-600 mb-2 text-sm"
      >
        ← Zurück
      </button>

      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">{project.name}</h2>
          <p className="text-sm text-slate-500">
            {project.customers?.name} · {project.customers?.address}
          </p>
        </div>
        <button
          onClick={() => navigate(`/angebote/neu/${project.id}`)}
          className="bg-accent text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-accent-dark flex items-center gap-2"
        >
          📄 Angebot erstellen
        </button>
      </div>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="font-semibold text-slate-700 mb-4">Projektdaten</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Projektname</label>
                <input
                  value={project.name}
                  onChange={(e) => setProject({ ...project, name: e.target.value })}
                  onBlur={() => handleSave({ name: project.name })}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Status</label>
                <select
                  value={project.status}
                  onChange={(e) => {
                    setProject({ ...project, status: e.target.value })
                    handleSave({ status: e.target.value })
                  }}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
                >
                  <option>Offen</option>
                  <option>In Arbeit</option>
                  <option>Fertig</option>
                </select>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="font-semibold text-slate-700 mb-3">Notizen</h3>
            <textarea
              rows={4}
              value={project.notes || ''}
              onChange={(e) => setProject({ ...project, notes: e.target.value })}
              onBlur={() => handleSave({ notes: project.notes })}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
            />
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-700">Materialliste</h3>
              <button
                onClick={addMaterial}
                className="text-accent text-sm font-medium hover:underline"
              >
                + Position
              </button>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-slate-400 uppercase text-left">
                  <th className="py-2 font-medium">Artikel</th>
                  <th className="py-2 font-medium">Menge</th>
                  <th className="py-2 font-medium">Preis</th>
                  <th className="py-2" />
                </tr>
              </thead>
              <tbody>
                {project.materials.map((m, i) => (
                  <tr key={i} className="border-t border-slate-100">
                    <td className="py-2 pr-2">
                      <input
                        value={m.name}
                        onChange={(e) => updateMaterial(i, 'name', e.target.value)}
                        onBlur={() => handleSave({ materials: project.materials })}
                        className="w-full rounded border border-slate-200 px-2 py-1 text-sm"
                      />
                    </td>
                    <td className="py-2 pr-2 w-28">
                      <input
                        value={m.quantity}
                        onChange={(e) => updateMaterial(i, 'quantity', e.target.value)}
                        onBlur={() => handleSave({ materials: project.materials })}
                        className="w-full rounded border border-slate-200 px-2 py-1 text-sm"
                      />
                    </td>
                    <td className="py-2 pr-2 w-28">
                      <input
                        type="number"
                        step="0.01"
                        value={m.price}
                        onChange={(e) => updateMaterial(i, 'price', e.target.value)}
                        onBlur={() => handleSave({ materials: project.materials })}
                        className="w-full rounded border border-slate-200 px-2 py-1 text-sm"
                      />
                    </td>
                    <td className="py-2 text-right w-8">
                      <button
                        onClick={() => removeMaterial(i)}
                        className="text-slate-400 hover:text-red-500"
                      >
                        🗑
                      </button>
                    </td>
                  </tr>
                ))}
                {project.materials.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-4 text-slate-400 text-sm">
                      Noch keine Materialien erfasst.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="col-span-1">
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-700">Fotos</h3>
              <label className="text-accent text-sm font-medium hover:underline cursor-pointer">
                {uploading ? 'Lädt hoch …' : '↑ Hochladen'}
                <input type="file" accept="image/*" onChange={handleUpload} className="hidden" />
              </label>
            </div>
            {photos.length === 0 ? (
              <p className="text-sm text-slate-400">Noch keine Fotos hochgeladen.</p>
            ) : (
              <div className="space-y-3">
                {photos.map((url) => (
                  <img key={url} src={url} alt="Projektfoto" className="w-full rounded-lg object-cover" />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
