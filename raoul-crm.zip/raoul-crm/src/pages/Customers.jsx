import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import AppLayout from '../components/AppLayout.jsx'
import { getCustomers, createCustomer } from '../lib/supabase.js'

export default function Customers({ user }) {
  const [customers, setCustomers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showModal, setShowModal] = useState(false)

  async function load() {
    setLoading(true)
    try {
      setCustomers(await getCustomers())
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  async function handleCreate(form) {
    await createCustomer(form)
    setShowModal(false)
    load()
  }

  return (
    <AppLayout user={user} title="Kunden">
      <div className="flex items-center justify-between mb-1">
        <h2 className="text-2xl font-bold text-slate-800">Kunden</h2>
        <button
          onClick={() => setShowModal(true)}
          className="bg-sidebar text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-slate-800 transition flex items-center gap-2"
        >
          <span className="text-lg leading-none">+</span> Neuer Kunde
        </button>
      </div>
      <p className="text-sm text-slate-500 mb-6">{customers.length} Kunden insgesamt</p>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {loading ? (
          <p className="px-6 py-6 text-sm text-slate-400">Wird geladen …</p>
        ) : customers.length === 0 ? (
          <p className="px-6 py-6 text-sm text-slate-400">Noch keine Kunden angelegt.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-slate-400 uppercase text-left bg-slate-50">
                <th className="px-6 py-3 font-medium">Kunde</th>
                <th className="px-6 py-3 font-medium">Adresse</th>
                <th className="px-6 py-3 font-medium">Telefon</th>
                <th className="px-6 py-3 font-medium">Projekte</th>
                <th className="px-6 py-3" />
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-6 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center text-xs font-semibold">
                        {c.name?.charAt(0)}
                      </div>
                      <span className="font-medium text-slate-700">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-3 text-slate-500">{c.address}</td>
                  <td className="px-6 py-3 text-slate-500">{c.phone}</td>
                  <td className="px-6 py-3">
                    <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2 py-0.5 rounded">
                      {c.projects?.length ?? 0}
                    </span>
                  </td>
                  <td className="px-6 py-3 text-right">
                    <Link
                      to={`/kunden/${c.id}`}
                      className="text-accent text-sm font-medium hover:underline"
                    >
                      Details ›
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <CustomerModal onClose={() => setShowModal(false)} onSave={handleCreate} />
      )}
    </AppLayout>
  )
}

function CustomerModal({ onClose, onSave }) {
  const [form, setForm] = useState({ name: '', address: '', phone: '', notes: '' })
  const [saving, setSaving] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    try {
      await onSave(form)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-xl w-full max-w-md p-6">
        <h3 className="font-semibold text-slate-800 mb-4">Neuer Kunde</h3>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Name" required value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
          <Field label="Adresse" value={form.address} onChange={(v) => setForm({ ...form, address: v })} />
          <Field label="Telefon" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} />
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Notizen</label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={3}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
            >
              Abbrechen
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-sm rounded-lg bg-accent text-white font-medium hover:bg-accent-dark disabled:opacity-60"
            >
              {saving ? 'Speichern …' : 'Speichern'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, value, onChange, required }) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-500 mb-1">{label}</label>
      <input
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
      />
    </div>
  )
}
