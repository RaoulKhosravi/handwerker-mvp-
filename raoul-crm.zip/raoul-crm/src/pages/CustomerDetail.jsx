import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import AppLayout from '../components/AppLayout.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import { getCustomer, createProject } from '../lib/supabase.js'

export default function CustomerDetail({ user }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const [customer, setCustomer] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showModal, setShowModal] = useState(false)

  async function load() {
    setLoading(true)
    try {
      setCustomer(await getCustomer(id))
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [id])

  async function handleCreateProject(form) {
    await createProject({ ...form, customer_id: id })
    setShowModal(false)
    load()
  }

  if (loading) {
    return (
      <AppLayout user={user} title="Kundendetails">
        <p className="text-sm text-slate-400">Wird geladen …</p>
      </AppLayout>
    )
  }

  if (error || !customer) {
    return (
      <AppLayout user={user} title="Kundendetails">
        <p className="text-sm text-red-600">{error || 'Kunde nicht gefunden.'}</p>
      </AppLayout>
    )
  }

  const projects = customer.projects || []
  const projectTotal = (p) =>
    (p.invoices || []).reduce((sum, inv) => sum + Number(inv.total || 0), 0)
  const totalRevenue = projects.reduce((sum, p) => sum + projectTotal(p), 0)
  const lastContact = projects
    .map((p) => p.created_at)
    .sort()
    .reverse()[0]

  return (
    <AppLayout user={user} title="Kundendetails">
      <button
        onClick={() => navigate('/kunden')}
        className="text-slate-400 hover:text-slate-600 mb-2 text-sm"
      >
        ← Zurück
      </button>
      <h2 className="text-2xl font-bold text-slate-800">{customer.name}</h2>
      <p className="text-sm text-slate-500 mb-6">
        Stammkunde seit{' '}
        {new Date(customer.created_at).toLocaleDateString('de-DE', {
          month: 'long',
          year: 'numeric'
        })}
      </p>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-1 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-accent text-white flex items-center justify-center font-semibold">
                {customer.name?.charAt(0)}
              </div>
              <div>
                <div className="font-semibold text-slate-800">{customer.name}</div>
                <div className="text-xs text-slate-400">Privatkunde</div>
              </div>
            </div>
            <div className="space-y-3 text-sm">
              <div>
                <div className="text-xs text-slate-400 mb-0.5">Adresse</div>
                <div className="text-slate-700">{customer.address || '–'}</div>
              </div>
              <div>
                <div className="text-xs text-slate-400 mb-0.5">Telefon</div>
                <div className="text-slate-700">{customer.phone || '–'}</div>
              </div>
              <div>
                <div className="text-xs text-slate-400 mb-0.5">Notizen</div>
                <div className="text-slate-700">{customer.notes || '–'}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 text-sm">
            <div className="text-xs text-slate-400 uppercase mb-3">Zusammenfassung</div>
            <SummaryRow label="Projekte gesamt" value={projects.length} />
            <SummaryRow
              label="Umsatz gesamt"
              value={`${totalRevenue.toLocaleString('de-DE', { minimumFractionDigits: 0 })} €`}
            />
            <SummaryRow
              label="Letzter Kontakt"
              value={lastContact ? new Date(lastContact).toLocaleDateString('de-DE') : '–'}
            />
          </div>
        </div>

        <div className="col-span-2">
          <div className="bg-white rounded-xl border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-semibold text-slate-700">Projekte</h3>
              <button
                onClick={() => setShowModal(true)}
                className="bg-sidebar text-white text-sm font-medium px-3 py-1.5 rounded-lg hover:bg-slate-800"
              >
                + Neues Projekt
              </button>
            </div>
            {projects.length === 0 ? (
              <p className="px-6 py-6 text-sm text-slate-400">Noch keine Projekte für diesen Kunden.</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-slate-400 uppercase text-left">
                    <th className="px-6 py-2 font-medium">Projekt</th>
                    <th className="px-6 py-2 font-medium">Datum</th>
                    <th className="px-6 py-2 font-medium">Status</th>
                    <th className="px-6 py-2 font-medium text-right">Betrag</th>
                  </tr>
                </thead>
                <tbody>
                  {projects.map((p) => (
                    <tr key={p.id} className="border-t border-slate-100 hover:bg-slate-50">
                      <td className="px-6 py-3">
                        <Link to={`/projekte/${p.id}`} className="text-slate-700 font-medium hover:text-accent">
                          {p.name}
                        </Link>
                      </td>
                      <td className="px-6 py-3 text-slate-500">
                        {new Date(p.created_at).toLocaleDateString('de-DE')}
                      </td>
                      <td className="px-6 py-3">
                        <StatusBadge status={p.status} />
                      </td>
                      <td className="px-6 py-3 text-right text-slate-700">
                        {projectTotal(p) > 0
                          ? `${projectTotal(p).toLocaleString('de-DE')} €`
                          : '–'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {showModal && (
        <ProjectModal onClose={() => setShowModal(false)} onSave={handleCreateProject} />
      )}
    </AppLayout>
  )
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex justify-between py-1.5">
      <span className="text-slate-500">{label}</span>
      <span className="font-medium text-slate-800">{value}</span>
    </div>
  )
}

function ProjectModal({ onClose, onSave }) {
  const [form, setForm] = useState({ name: '', status: 'Offen', notes: '' })
  const [saving, setSaving] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    try {
      await onSave(form)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-xl w-full max-w-md p-6">
        <h3 className="font-semibold text-slate-800 mb-4">Neues Projekt</h3>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Projektname</label>
            <input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Status</label>
            <select
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
            >
              <option>Offen</option>
              <option>In Arbeit</option>
              <option>Fertig</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Notizen</label>
            <textarea
              rows={3}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
            >
              Abbrechen
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-sm rounded-lg bg-accent text-white font-medium hover:bg-accent-dark disabled:opacity-60"
            >
              {saving ? 'Speichern …' : 'Speichern'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
