import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import AppLayout from '../components/AppLayout.jsx'
import { getInvoices } from '../lib/supabase.js'

export default function Offers({ user }) {
  const [invoices, setInvoices] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    getInvoices()
      .then(setInvoices)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [])

  return (
    <AppLayout user={user} title="Angebote">
      <h2 className="text-2xl font-bold text-slate-800 mb-1">Angebote</h2>
      <p className="text-sm text-slate-500 mb-6">{invoices.length} Angebote insgesamt</p>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {loading ? (
          <p className="px-6 py-6 text-sm text-slate-400">Wird geladen …</p>
        ) : invoices.length === 0 ? (
          <p className="px-6 py-6 text-sm text-slate-400">Noch keine Angebote erstellt.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-slate-400 uppercase text-left bg-slate-50">
                <th className="px-6 py-3 font-medium">Titel</th>
                <th className="px-6 py-3 font-medium">Projekt</th>
                <th className="px-6 py-3 font-medium">Kunde</th>
                <th className="px-6 py-3 font-medium">Datum</th>
                <th className="px-6 py-3 font-medium text-right">Betrag</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv) => (
                <tr key={inv.id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-6 py-3">
                    <Link
                      to={`/angebote/${inv.id}`}
                      className="text-slate-700 font-medium hover:text-accent"
                    >
                      {inv.title}
                    </Link>
                  </td>
                  <td className="px-6 py-3 text-slate-500">{inv.projects?.name}</td>
                  <td className="px-6 py-3 text-accent">{inv.projects?.customers?.name}</td>
                  <td className="px-6 py-3 text-slate-500">
                    {new Date(inv.date).toLocaleDateString('de-DE')}
                  </td>
                  <td className="px-6 py-3 text-right text-slate-700">
                    {Number(inv.total).toLocaleString('de-DE')} €
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </AppLayout>
  )
}
