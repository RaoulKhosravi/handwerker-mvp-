/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Dunkle Sidebar-Farbe aus dem Figma-Design
        sidebar: '#1a1f2e',
        // Orange Akzentfarbe (Buttons, aktive States, Icon)
        accent: {
          DEFAULT: '#f0883e',
          dark: '#e8730f'
        },
        // Heller Content-Hintergrund
        surface: '#f5f6f8'
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif']
      }
    }
  },
  plugins: []
}
