-- =========================================================
-- Supabase Schema: Kunden / Projekte / Rechnungen
-- =========================================================

-- Hilfsfunktion, die updated_at bei jedem UPDATE automatisch setzt
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- =========================================================
-- users
-- =========================================================
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger trg_users_updated_at
before update on users
for each row execute function set_updated_at();

-- =========================================================
-- customers
-- =========================================================
create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text,
  phone text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger trg_customers_updated_at
before update on customers
for each row execute function set_updated_at();

-- =========================================================
-- projects
-- =========================================================
create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references customers(id) on delete cascade,
  name text not null,
  status text not null default 'open',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_projects_customer_id on projects(customer_id);

create trigger trg_projects_updated_at
before update on projects
for each row execute function set_updated_at();

-- =========================================================
-- invoices
-- =========================================================
create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  date date not null default current_date,
  total numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_invoices_project_id on invoices(project_id);

create trigger trg_invoices_updated_at
before update on invoices
for each row execute function set_updated_at();

-- =========================================================
-- invoice_items
-- =========================================================
create table if not exists invoice_items (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id) on delete cascade,
  description text not null,
  quantity numeric(12,2) not null default 1,
  price numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_invoice_items_invoice_id on invoice_items(invoice_id);

create trigger trg_invoice_items_updated_at
before update on invoice_items
for each row execute function set_updated_at();

-- =========================================================
-- Optional: Row Level Security aktivieren
-- (Standardmäßig sperrt das alle Zugriffe, bis du Policies anlegst.
--  Zum schnellen Testen erstmal auskommentiert lassen.)
-- =========================================================
-- alter table customers enable row level security;
-- alter table projects enable row level security;
-- alter table invoices enable row level security;
-- alter table invoice_items enable row level security;
