import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Leitet Aufrufe an /api während der lokalen Entwicklung an den
      // Vercel-Dev-Server weiter (`vercel dev` parallel laufen lassen).
      '/api': 'http://localhost:3000'
    }
  }
})
