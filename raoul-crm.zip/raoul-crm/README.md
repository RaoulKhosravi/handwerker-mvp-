# Raoul CRM

React-Webapp (Vite) für Handwerk & Projektmanagement mit Supabase-Auth,
CRUD für Kunden/Projekte/Angebote und serverseitigem PDF-Export.

## Setup

1. **Abhängigkeiten installieren**
   ```
   npm install
   ```

2. **Supabase-Projekt anlegen** unter https://supabase.com, dann im SQL-Editor
   nacheinander ausführen:
   - `supabase_schema.sql` (Basis-Tabellen — aus dem ersten Chat-Schritt)
   - `supabase_extra.sql` (materials-Spalte, RLS-Policies, Storage-Bucket)

3. **Umgebungsvariablen**
   ```
   cp .env.example .env
   ```
   und `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` aus
   Supabase → Project Settings → API eintragen.

4. **Lokal starten**
   ```
   npm run dev
   ```
   Für den PDF-Endpunkt (`/api/pdf.js`) läuft die App am einfachsten über
   Vercel: `npx vercel dev` startet Frontend + Serverless-Function zusammen.
   Alternativ kann `api/pdf.js` in eine eigene Node/Express-Route
   umgezogen werden, falls du nicht auf Vercel deployst.

5. **Ersten Nutzer anlegen**: auf der Login-Seite auf "Registrieren" klicken,
   oder in Supabase → Authentication → Users manuell einen Nutzer erstellen.

## Ordnerstruktur

```
/src/pages          Login, Dashboard, Customers, CustomerDetail,
                     Projects, ProjectDetail, Offers, OfferCreate
/src/components      Sidebar, AppLayout, StatusBadge
/src/lib/supabase.js Supabase-Client + alle DB-Zugriffsfunktionen
/api/pdf.js          Serverless-Function für den PDF-Export (pdf-lib)
```

## Bekannte Vereinfachungen (nächste Schritte)

- RLS ist aktuell "alle eingeloggten Nutzer sehen alles" — für Mandantentrennung
  bräuchte es eine `user_id`-Spalte + entsprechend engere Policies.
- E-Mail-Versand des Angebots-PDFs ist in der UI vorbereitet (Hinweistext),
  aber noch nicht implementiert — würde einen weiteren API-Endpunkt
  (z. B. über Resend oder Supabase Edge Function) benötigen.
- Der Datei-Upload für Projektfotos nutzt Supabase Storage direkt aus dem
  Frontend; für große Dateien lohnt sich später eine Kompression vor dem Upload.
