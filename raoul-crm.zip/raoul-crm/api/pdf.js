import { PDFDocument, StandardFonts, rgb } from 'pdf-lib'

// Vercel Serverless Function: POST /api/pdf
// Erwartet die Angebotsdaten im Body und liefert ein fertiges PDF zurück.
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' })
    return
  }

  try {
    const {
      title = 'Angebot',
      date,
      validUntil,
      customerName = '',
      paymentTerms = '',
      remarks = '',
      items = [],
      netTotal = 0,
      vat = 0,
      grandTotal = 0
    } = req.body

    const pdfDoc = await PDFDocument.create()
    const page = pdfDoc.addPage([595.28, 841.89]) // A4
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica)
    const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold)

    const orange = rgb(0.94, 0.53, 0.24)
    const dark = rgb(0.13, 0.15, 0.2)
    const gray = rgb(0.45, 0.48, 0.53)

    let y = 800

    page.drawText('Raoul CRM', { x: 50, y, size: 18, font: bold, color: dark })
    page.drawText('Handwerk & Projektmanagement', {
      x: 50,
      y: y - 16,
      size: 9,
      font,
      color: gray
    })

    page.drawText(title, { x: 50, y: y - 60, size: 16, font: bold, color: dark })
    page.drawText(`Kunde: ${customerName}`, { x: 50, y: y - 82, size: 10, font, color: gray })
    page.drawText(`Datum: ${formatDate(date)}`, { x: 400, y: y - 60, size: 10, font, color: gray })
    if (validUntil) {
      page.drawText(`Gültig bis: ${formatDate(validUntil)}`, {
        x: 400,
        y: y - 76,
        size: 10,
        font,
        color: gray
      })
    }

    y -= 120

    // Tabellenkopf
    const cols = { desc: 50, qty: 340, price: 400, total: 480 }
    page.drawText('Beschreibung', { x: cols.desc, y, size: 9, font: bold, color: gray })
    page.drawText('Menge', { x: cols.qty, y, size: 9, font: bold, color: gray })
    page.drawText('Preis', { x: cols.price, y, size: 9, font: bold, color: gray })
    page.drawText('Gesamt', { x: cols.total, y, size: 9, font: bold, color: gray })
    y -= 8
    page.drawLine({
      start: { x: 50, y },
      end: { x: 545, y },
      thickness: 0.5,
      color: rgb(0.85, 0.85, 0.87)
    })
    y -= 18

    for (const item of items) {
      const qty = Number(item.quantity || 0)
      const price = Number(item.price || 0)
      const lineTotal = qty * price

      page.drawText(truncate(item.description || '', 55), {
        x: cols.desc,
        y,
        size: 10,
        font,
        color: dark
      })
      page.drawText(String(qty), { x: cols.qty, y, size: 10, font, color: dark })
      page.drawText(`${price.toFixed(2)} €`, { x: cols.price, y, size: 10, font, color: dark })
      page.drawText(`${lineTotal.toFixed(2)} €`, { x: cols.total, y, size: 10, font, color: dark })
      y -= 20
    }

    y -= 10
    page.drawLine({
      start: { x: 340, y },
      end: { x: 545, y },
      thickness: 0.5,
      color: rgb(0.85, 0.85, 0.87)
    })
    y -= 20

    drawSummaryRow(page, 'Nettobetrag', netTotal, y, font, gray, dark)
    y -= 18
    drawSummaryRow(page, 'MwSt. (19 %)', vat, y, font, gray, dark)
    y -= 22
    page.drawText('Gesamtbetrag', { x: 340, y, size: 11, font: bold, color: dark })
    page.drawText(`${Number(grandTotal).toFixed(2)} €`, {
      x: 480,
      y,
      size: 11,
      font: bold,
      color: orange
    })

    y -= 50
    if (paymentTerms) {
      page.drawText(`Zahlungsziel: ${paymentTerms}`, { x: 50, y, size: 9, font, color: gray })
      y -= 16
    }
    if (remarks) {
      page.drawText(truncate(remarks, 100), { x: 50, y, size: 9, font, color: gray })
    }

    const pdfBytes = await pdfDoc.save()

    res.setHeader('Content-Type', 'application/pdf')
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${(title || 'Angebot').replace(/[^a-z0-9\-_]+/gi, '_')}.pdf"`
    )
    res.status(200).send(Buffer.from(pdfBytes))
  } catch (err) {
    console.error('PDF generation error:', err)
    res.status(500).json({ error: 'PDF-Erstellung fehlgeschlagen' })
  }
}

function drawSummaryRow(page, label, value, y, font, gray, dark) {
  page.drawText(label, { x: 340, y, size: 10, font, color: gray })
  page.drawText(`${Number(value).toFixed(2)} €`, { x: 480, y, size: 10, font, color: dark })
}

function formatDate(value) {
  if (!value) return '–'
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) return value
  return d.toLocaleDateString('de-DE')
}

function truncate(str, max) {
  return str.length > max ? str.slice(0, max - 1) + '…' : str
}
