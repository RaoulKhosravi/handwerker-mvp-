-- =========================================================
-- Ergänzung zum Basis-Schema (siehe erstes SQL-Skript)
-- Führe dies NACH dem Basis-Schema im Supabase SQL-Editor aus.
-- =========================================================

-- Materialliste je Projekt als einfaches JSON-Array
alter table projects add column if not exists materials jsonb not null default '[]';

-- =========================================================
-- Row Level Security: alle eingeloggten Nutzer dürfen lesen/schreiben
-- (passend für eine Single-Tenant-App wie Raoul CRM; für mehrere
--  getrennte Firmen müsste man zusätzlich nach user_id filtern)
-- =========================================================
alter table customers enable row level security;
alter table projects enable row level security;
alter table invoices enable row level security;
alter table invoice_items enable row level security;

create policy "Authenticated full access" on customers
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Authenticated full access" on projects
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Authenticated full access" on invoices
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Authenticated full access" on invoice_items
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- =========================================================
-- Storage-Bucket für Projektfotos
-- =========================================================
insert into storage.buckets (id, name, public)
values ('project-photos', 'project-photos', true)
on conflict (id) do nothing;

create policy "Authenticated can upload project photos"
on storage.objects for insert
with check (bucket_id = 'project-photos' and auth.role() = 'authenticated');

create policy "Anyone can view project photos"
on storage.objects for select
using (bucket_id = 'project-photos');

create policy "Authenticated can delete project photos"
on storage.objects for delete
using (bucket_id = 'project-photos' and auth.role() = 'authenticated');
